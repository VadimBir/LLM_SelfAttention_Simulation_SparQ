012-L2_NxtLine_1-2-4_IPStride_s32k_d18.log:                                         inst: 350M  AVG IPC: 0.81923 (Sim:0h38m56s) 
--
012-L2_NxtLine_1-2-4_IPStride_s32k_d26.log:                                         inst: 350M  AVG IPC: 0.81923 (Sim:0h32m9s) 
--
012-L2_NxtLine_1-2-4_IPStride_s32k_d32.log:                                         inst: 350M  AVG IPC: 0.81923 (Sim:0h31m6s) 
--
012-L2_NxtLine_1-2-4_IPStride_s64k_d22.log:                                         inst: 350M  AVG IPC: 0.81923 (Sim:0h54m28s) 
--
012-L2_NxtLine_1-2-4_IPStride_s64k_d36.log:                                         inst: 350M  AVG IPC: 0.81923 (Sim:0h54m42s) 
--
015-L2_NxtLine_1-2-4_IPStride_s16k_d18_deltaMarkov_s8k_MaxP10_T16.log:              inst: 350M  AVG IPC: 0.81825 (Sim:2h17m25s) 
--
015-L2_NxtLine_1-2-4_IPStride_s32k_d21_deltaMarkov_s8k_MaxP10_T16.log:              inst: 350M  AVG IPC: 0.81825 (Sim:2h34m4s) 
--
015-L2_NxtLine_1-2-4_IPStride_s32k_d24_deltaMarkov_s8k_MaxP10_T16.log:              inst: 350M  AVG IPC: 0.81825 (Sim:2h37m41s) 
--
015-L2_NxtLine_1-2-4_IPStride_s32k_d32_deltaMarkov_s8k_MaxP10_T16.log:              inst: 350M  AVG IPC: 0.81825 (Sim:2h36m26s) 
--
021-L2_NxtLine_1-2-4_IPStride_s32k_d16_deltaMarkov_s8k_MaxP16_T20.log:              inst: 350M  AVG IPC: 0.81813 (Sim:2h35m58s) 
--
022-L2_NxtLine_1-2-4_IPStride_s16k_d14_deltaMarkov_s8k_MaxP10_T16.log:              inst: 350M  AVG IPC: 0.81793 (Sim:2h11m19s) 
--
023-L2_NxtLine_1-2-4_IPStride_s32k_d12_deltaMarkov_s8k_MaxP10_T16.log:              inst: 350M  AVG IPC: 0.81742 (Sim:2h47m48s) 
--
024-L2_NxtLine_1-2-4_IPStride_s32k_d10_deltaMarkov_s8k_MaxP10_T16.log:              inst: 350M  AVG IPC: 0.81680 (Sim:2h46m56s) 
--
025-L2_IP_delta_markov_S4k_MaxP10_T16_Nxt_NxtNxtLine_V3.log:                        inst: 360M  AVG IPC: 0.81631 (Sim:0h39m0s)
--
025-L2_NxtLine_1-2-4_IPStride_s32k_d10_deltaMarkov_s16k_MaxP10_T16.log:             inst: 350M  AVG IPC: 0.81628 (Sim:4h25m33s) 
--
027-L2_NxtLine_1-2-4_IPStride_s16k_d8_deltaMarkov_s8k_MaxP10_T16.log:               inst: 350M  AVG IPC: 0.81570 (Sim:1h45m38s) 
--
030-L2_NxtLine_1-2-4_IPStride_s16k_d2_deltaMarkov_s8k_MaxP10_T16.log:               inst: 350M  AVG IPC: 0.81400 (Sim:1h47m39s) 
--
030-L2_NxtLine_1-2-4_IPStride_s32k_d2_deltaMarkov_s8k_MaxP10_T16.log:               inst: 350M  AVG IPC: 0.81400 (Sim:2h7m1s) 
--
030-L2_NxtLine_1-2-4_IPStride_s8k_d2_deltaMarkov_s8k_MaxP10_T16.log:                inst: 350M  AVG IPC: 0.81400 (Sim:1h39m15s) 
--
031-L2_delta_markov_S8k_MaxP10_T16_NxtLine_1-2-4.log:                               inst: 350M  AVG IPC: 0.81385 (Sim:4h44m6s) 
--
032-L2_AlignedFiltered-delta_markov_S4k_MaxP10_T16_NxtLine_1-2-4.log:               inst: 350M  AVG IPC: 0.81365 (Sim:2h20m28s) 
--
032-L2_delta_markov_S8k_MaxP10_T16_NxtLine_2-1-4.log:                               inst: 350M  AVG IPC: 0.81235 (Sim:4h46m54s) 
--
033-L2_NxtLine_1-2-4_IPStride_s8k_d4.log:                                           inst: 350M  AVG IPC: 0.81054 (Sim:0h28m2s) 
--
034-L2_NxtLine_1-2-4_IPStride_s8k_d2.log:                                           inst: 350M  AVG IPC: 0.81025 (Sim:0h28m6s) 
--
036-L2_EntroryFiltering-delta_markov_S4k_MaxP10_T16_NxtLine_1-2-4.log:              inst: 350M  AVG IPC: 0.81020 (Sim:2h48m0s) 
--
036-L2_NxtLine_1-2-4_IPStride_s8k_d1.log:                                           inst: 350M  AVG IPC: 0.81021 (Sim:0h28m34s) 
--
037-L2_EDecay-delta_markov_S4k_MaxP10_T16_NxtLine_1-2-4.log:                        inst: 350M  AVG IPC: 0.81018 (Sim:2h46m13s) 
--
037-L2_MLEdelta_markov_S4k_MaxP10_T16_NxtLine_1-2-4.log:                            inst: 350M  AVG IPC: 0.81018 (Sim:2h38m52s) 
--
039-L2_deltaMarkov_S8k_MaxP10_Threshold16_NxtNxtLine_L1_NxtLine.log:                inst: 2Bill AVG IPC: 0.80923 (Sim:10h48m10s) 
--
041-L2_deltaMarkov_S8k_MaxP10_Threshold16_L1_NxtNxtLine_NxtLine.log:                inst: 2Bill AVG IPC: 0.80727 (Sim:11h51m34s) 
--
043-L2_deltaMarkov_S4k_MaxP10_Threshold16_L1_NxtNxtLine_NxtLine.log:                inst: 2Bill AVG IPC: 0.80495 (Sim:5h8m3s) 
--
050-8K_deltaMarkov_MaxP10_Thresh16_Nxt_NxtNxt_Line.log:                             inst: 2Bill AVG IPC: 0.79320 (Sim:6h36m28s) 
--
050-8K_deltaMarkov_MaxP12_Thresh36_Nxt_NxtNxt_Line.log:                             inst: 2Bill AVG IPC: 0.79337 (Sim:6h16m15s) 
--
070-4K_deltaMarkov_MaxP12_Thresh16_Nxt_NxtNxt_Line.log:                             inst: 2Bill AVG IPC: 0.79222 (Sim:3h49m32s) 
--
071-4K_deltaMarkov_MaxP10_Thresh16_Nxt_NxtNxt_Line.log:                             inst: 2Bill AVG IPC: 0.79223 (Sim:3h48m49s) 
--
080-DeltaDeltaMarkovPrefetcher_Size_8K_MaxP_8_Thresh_16_NxtLine_NxtNxtLine.log:     inst: 2Bill AVG IPC: 0.78841 (Sim:7h41m45s) 
--
085-DeltaDeltaMarkovPrefetcher_Size_4K_MaxP_8_Thresh_12_NxtLine_NxtNxtLine.log:     inst: 2Bill AVG IPC: 0.78614 (Sim:3h39m42s) 
--
086-L2_NxtLine_NxtNxtLine_L1_deltaMarkov_S8k_MaxP10_Threshold16.log:                inst: 2Bill AVG IPC: 0.78304 (Sim:17h44m49s) 
--
087-DeltaDeltaMarkovPrefetcher_Size_4K_MaxP_4_Thresh_8_NxtLine_NxtNxtLine.log:      inst: 2Bill AVG IPC: 0.78051 (Sim:3h37m16s) 
--
088-DeltaDeltaMarkovPrefetcher__Size_2K_MaxP_4_Thresh_24_NxtLine_NxtNxtLine.log:    inst: 2Bill AVG IPC: 0.77953 (Sim:4h14m39s) 
--
089-NxtNxtLine_NxtLine_L2_deltaMarkov_S4k_MaxP10_Threshold16_L1.log:                inst: 2Bill AVG IPC: 0.77076 (Sim:1h31m55s) 
--
090-ONLY_DeltaMarkovPrefetcher_V5_MaxP_16_Thresh_24.log:                            inst: 2Bill AVG IPC: 0.65748 (Sim:6h40m8s) 
--
094-ONLY_DeltaDeltaMarkovPrefetcher_V3_Size_2K_MaxP_10_Thresh_4.log:                inst: 2Bill AVG IPC: 0.62783 (Sim:5h15m36s) 
--
095-nxt_1_nxt_2_2B_simulation.log:                                                  inst: 2Bill AVG IPC: 0.77068 (Sim:1h30m22s)
--
097-4K_4D_Stride_Only.log:                                                          inst: 2Bill AVG IPC: 0.62559 (Sim:1h8m23s) 
--
098-LRU_Locality.log:                                                               inst: 2Bill AVG IPC: 0.55932 (Sim:2h56m16s) 
--
099-base_LRU_2B_simulation.log:                                                     inst: 2Bill AVG IPC: 0.55932 (Sim:1h5m39s)
--
999-markov_2B_ParamBruteForce_simulation.log:                                       inst: 2Bill AVG IPC: 0.65599 (Sim:5h17m57s)
--
999-markov_2B_ParamBruteForce_simulation.log:                                       inst: 2Bill AVG IPC: 0.65656 (Sim:5h8m53s)
--
999-nxt_1_nxt_2_markov_2B_simulation.log:                                           inst: 2Bill AVG IPC: 0.77269 (Sim:3h11m49s)
