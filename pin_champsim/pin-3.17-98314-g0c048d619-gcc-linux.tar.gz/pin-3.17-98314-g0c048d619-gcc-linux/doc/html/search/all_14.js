var searchData=
[
  ['vsyscall_5fnr',['VSYSCALL_NR',['../group__INS__BASIC__API__GEN__IA32.html#gadbadb75824ee34bd10c14c7a5288f5c2',1,'LEVEL_CORE']]]
];
