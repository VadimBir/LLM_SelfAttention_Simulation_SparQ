var searchData=
[
  ['regdef_5fentry',['REGDEF_ENTRY',['../structLEVEL__BASE_1_1REGDEF__ENTRY.html',1,'LEVEL_BASE']]],
  ['register_5fset',['REGISTER_SET',['../classLEVEL__CORE_1_1REGISTER__SET.html',1,'LEVEL_CORE']]]
];
