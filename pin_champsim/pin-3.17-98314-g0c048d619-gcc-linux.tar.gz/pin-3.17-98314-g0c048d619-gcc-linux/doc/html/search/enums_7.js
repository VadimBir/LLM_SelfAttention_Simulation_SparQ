var searchData=
[
  ['memory_5ftype',['MEMORY_TYPE',['../group__INS__BASIC__API__GEN__IA32.html#ga22e078aff830383cf6c1be6e04382aae',1,'LEVEL_CORE']]]
];
