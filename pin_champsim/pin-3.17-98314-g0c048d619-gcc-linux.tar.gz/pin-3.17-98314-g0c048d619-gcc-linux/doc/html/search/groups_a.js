var searchData=
[
  ['miscellaneous_20functions',['Miscellaneous functions',['../group__MISC.html',1,'']]]
];
