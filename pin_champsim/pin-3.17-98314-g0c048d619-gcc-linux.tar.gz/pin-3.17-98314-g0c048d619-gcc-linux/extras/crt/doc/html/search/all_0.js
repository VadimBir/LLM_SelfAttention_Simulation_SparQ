var searchData=
[
  ['_5fos_5fapis_5fmutex_5ftype',['_OS_APIS_MUTEX_TYPE',['../struct__OS__APIS__MUTEX__TYPE.html',1,'']]],
  ['_5fos_5ffile_5funique_5fid',['_OS_FILE_UNIQUE_ID',['../struct__OS__FILE__UNIQUE__ID.html',1,'']]],
  ['_5fos_5freturn_5fcode',['_OS_RETURN_CODE',['../struct__OS__RETURN__CODE.html',1,'']]],
  ['_5fos_5freturn_5fcode_5fposix',['_OS_RETURN_CODE_POSIX',['../struct__OS__RETURN__CODE__POSIX.html',1,'']]],
  ['_5fsa_5fhandler_5fptr',['_sa_handler_ptr',['../structSIGACTION.html#ad306ef8350ea4554a0a4cdde674372a6',1,'SIGACTION']]],
  ['_5fsa_5fsigaction',['_sa_sigaction',['../structSIGACTION.html#a2f8bd550d8503fac198aac68b7bba244',1,'SIGACTION']]]
];
