/*
 * Copyright (C) 2009-2021 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

__declspec(dllexport) int exported_data1 = 7;

int main() { return 0; }
